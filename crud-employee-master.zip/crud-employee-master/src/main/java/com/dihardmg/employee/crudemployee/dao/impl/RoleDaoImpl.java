package com.dihardmg.employee.crudemployee.dao.impl;

import com.dihardmg.employee.crudemployee.dao.RoleDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

@Repository
public class RoleDaoImpl implements RoleDao {

    @Autowired
    private EntityManager entityManager;

    @Override
    public void crearRole(String id, String nombre) {
        //"login" this is the name of your procedure
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery("sp_roles2");

        //Declare the parameters in the same order
        query.registerStoredProcedureParameter(1, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(2, String.class, ParameterMode.IN);
        //query.registerStoredProcedureParameter(3, Integer.class, ParameterMode.OUT);
        //query.registerStoredProcedureParameter(4, String.class, ParameterMode.OUT);

        //Pass the parameter values
        query.setParameter(1, id);
        query.setParameter(2, nombre);

        //Execute query
        query.execute();

        //Get output parameters
        //Integer outCode = (Integer) query.getOutputParameterValue(3);
        //String outMessage = (String) query.getOutputParameterValue(4);
    }
}
