package com.dihardmg.employee.crudemployee.controller;

import com.dihardmg.employee.crudemployee.dao.StudentDao;
import com.dihardmg.employee.crudemployee.entity.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;

import javax.validation.Valid;

/**
 * @author : Otorus
 * @since : 12/23/17
 */
@Controller
@RequestMapping("/student")
public class StudentController {

    @Autowired
    private StudentDao studentDao;

    @GetMapping("/list2")
    public ModelMap listaStudent(@PageableDefault(size = 5)Pageable pageable, @RequestParam(name = "value", required = false) String value, Model model){
        if (value != null){
            model.addAttribute("key", value);
            return new ModelMap().addAttribute("listaStudent", studentDao.findByUsernameContainingIgnoreCase(value, pageable));
        }else {
            return new ModelMap().addAttribute("listaStudent", studentDao.findAll(pageable));
        }
    }

    @RequestMapping("/hapus")
    public String hapus (@RequestParam("id") String id){
        studentDao.delete(id);
        return "redirect:list2";
    }

    @GetMapping("/form2")
    public ModelMap tapilkanForm(@RequestParam(value = "id",required = false)Student student){
        if(student == null){
            student = new Student();
        }
        return new ModelMap("student", student);
    }


    @PostMapping("/form2")
    public String simpan(@ModelAttribute @Valid Student student, BindingResult errors, SessionStatus status){
        if (errors.hasErrors()){
            return "student/form2";
        }
        studentDao.save(student);
        status.setComplete();
        return "redirect:list2";
    }

}
