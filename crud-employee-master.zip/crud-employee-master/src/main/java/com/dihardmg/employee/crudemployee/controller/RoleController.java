package com.dihardmg.employee.crudemployee.controller;

import com.dihardmg.employee.crudemployee.dao.RoleDao;
import com.dihardmg.employee.crudemployee.forms.RolesForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;


@Controller
@RequestMapping("/roles")
public class RoleController {

    @Autowired
    private RoleDao roleDao;

    @GetMapping("/form")
    public String form(ModelMap model){
        RolesForm rolesForm = new RolesForm();
        model.addAttribute("roles", rolesForm);
        return "roles/form";
    }


    @PostMapping("/form")
    public String agregar(@ModelAttribute(value = "roles") RolesForm rolesForm, BindingResult errors, SessionStatus status) {
        if (errors.hasErrors()) {
            return "roles/form";
        }
        //employeeDao.save(employee);
        roleDao.crearRole(rolesForm.getId(), rolesForm.getNama());
        // status.setComplete();
           return "redirect:form";
    }

}
