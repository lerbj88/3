package com.dihardmg.employee.crudemployee.dao;

public interface RoleDao {

    void crearRole(String id, String nombre);
}
