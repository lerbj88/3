package com.dihardmg.employee.crudemployee.dao.impl;

import com.dihardmg.employee.crudemployee.dao.RoleDao;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class RoleDaoImplTest {

    @Resource
    private RoleDao roleDao;

    @Test
    public void crearRole() {
        roleDao.crearRole("3332","44442");
    }
}